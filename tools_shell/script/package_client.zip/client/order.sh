#!/bin/bash

#变量配置
project_name=order
project_version=$1
application_check_port=7070
debug=${2:-false}
current_date=$(date +'%Y-%m-%d')
current_timestamp=$(date +'%Y-%m-%d-%H-%M-%S')
dubbo_log=/usr/local/dubbo/${project_name}/logs/stdout.log
logfile=/script/logs/${project_name}.log
rollbacksh=/usr/local/dubbo/${project_name}/bin/rollback.sh

#打印日志
print_log(){
	echo "[$(date +'%Y-%m-%d %H:%M:%S')]${1}" | tee -a ${logfile}
}

#处理发包前后Dubbo的启动日志
clear_log(){
    append_text="${1}"
    cp ${dubbo_log} ${dubbo_log}.${append_text} 2>&1 1>/dev/null
    /bin/cat /dev/null > ${dubbo_log} 2>&1 1>/dev/null
}

#计算Dubbo启动耗时
calc_diff_time(){
    ts2=$(date +'%s')
    let tt=ts2-ts1
    print_log "本次发包共耗时${tt}秒"
}
calc_check_grant_one_minute(){
    ts2=$(date +'%s')
    let tt=ts2-ts1
    if [ $tt -gt 60 ]; then
        echo 0
    else
        echo 1
    fi
}

#检测应用端口是否启动
check_dubbo_port(){
    err_code=$1
    ok_msg=$2
    err_msg=$3
    netstat -lnp 2>/dev/null | grep 7070 2>&1 1>/dev/null
    if [ $? -eq 0 ]; then
        print_log "${ok_msg}"
		err_code=0
    else
        print_log "${err_msg}"
    fi
    calc_diff_time
    exit ${err_code}
}

#检测Dubbo启动完成
check_dubbo_startup_status(){
    egrep -q 'Dubbo service server started!' ${dubbo_log}
    if [ $? -eq 0 ]; then
        [ "${debug}" == "true" ] && echo "" | tee -a ${logfile}
        print_log "Dubbo已启动完毕"
        check_dubbo_port 3 \
            "Dubbo服务已启动并且应用端口监听也已启动" \
            "Dubbo服务已启动，但应用端口监听没有启动，本次发布失败！"
    else 
        [ "${debug}" == "true" ] && print_log " 等待Dubbo启动完成..."
    fi
}

#检测检测脚本是否超时
check_check_timeout(){
	elapsetime=$(calc_check_grant_one_minute)
    if [ ${elapsetime} -eq 0 ]; then
        print_log "Dubbo状态检测超时！"
        check_dubbo_port 4 \
            "Dubbo服务无法检测是否启动，但应用端口监听已启动，本次发布成功！" \
            "Dubbo服务无法检测是否启动，应用程序端口监听没有启动，本次发布失败"
    fi
}

print_log "本次发包${current_timestamp}开始...."

#解压包
print_log "正在解压包${project_name}-${project_version}.zip"
unzip /home/admin/dubbo/${project_name}/${project_name}-${project_version}.zip \
    -d /home/admin/dubbo/${project_name} 2>&1 1>/dev/null
if [ $? -ne 0 ]; then
	print_log "包${project_name}-${project_version}.zip解压失败"
	print_log "本次发包${current_timestamp}失败!"
	exit 5
fi

#生成回滚脚本
print_log "正在创建回滚脚本 ${rollbacksh}"
echo '#!/bin/bash' > ${rollbacksh}
ls -l /usr/local/dubbo/${project_name}/lib/ | awk '{print "ln -svfT "$10" "$8}' >> ${rollbacksh}
echo "sh /usr/local/dubbo/${project_name}/bin/server.sh restart" >> ${rollbacksh}

print_log "正在创建链接文件"
ln -svfT /home/admin/dubbo/${project_name}/${project_name}-${project_version}/lib \
    /usr/local/dubbo/${project_name}/lib 2>&1 1>/dev/null
ls -l /usr/local/dubbo/${project_name}/lib 2>&1 1>/dev/null | tee -a ${logfile}

#重启Dubbo
print_log "正在清理Dubbo的stdout.log日志"
clear_log "${current_timestamp}"

print_log "正在停止Dubbo"
sh /usr/local/dubbo/${project_name}/bin/server.sh stop
clear_log "${current_timestamp}.stop"

print_log "正在启动Dubbo"
ts1=$(date +'%s')
nohup sh /usr/local/dubbo/${project_name}/bin/server.sh start &

#检测Dubbo应用状态
print_log "正在等待Dubbo启动应用..."
while [ true ] 
do
    [ "${debug}" == "true" ] && echo -n "[$(date +'%Y-%m-%d %H:%M:%S')]正在检测Dubbo应用启动状态" | tee -a ${logfile}
    
    #检测Dubbo应用是否已启动完成
    check_dubbo_startup_status
    
	#检测检测脚本是否超时（默认1分钟）
	check_check_timeout
    
    sleep 0.1
done

exit 0
