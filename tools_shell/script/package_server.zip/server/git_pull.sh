#!/bin/bash

git_work_dir=$1
git_origin=$2
git_branch=$3
git_log=./b.log

#加载配置文件
if [ -f ./setenv.sh ]; then
    . ./setenv.sh
fi

#切换分支
cd ${git_work_dir}
cat /dev/null > ${git_log}
git pull ${git_origin} ${git_branch} 2>&1 | tee ${git_log} ; errorcode=${PIPESTATUS[0]}
if [ "${errorcode}x" != "0x" ]; then
    echo "[$(date +'%Y-%m-%d %H:%M:%S')]获取分支 ${git_branch} 代码失败, code=${errorcode}"
    exit 2
else
    grep -q 'Already up-to-date.' ${git_log}
    if [ $? -eq 0 ]; then
        echo "[$(date +'%Y-%m-%d %H:%M:%S')]没有更新代码，本地代码已经是最新代码"
    else
        echo "[$(date +'%Y-%m-%d %H:%M:%S')]获取分支 ${git_branch} 代码成功"
    fi
fi
exit 0
