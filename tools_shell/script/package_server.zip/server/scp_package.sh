#!/bin/bash

package_name=$1
package_src=$2
package_target=$3
package_server=$4

echo "package_name=${package_name}"
echo "package_src=${package_src}"
echo "package_target=${package_target}"
echo "package_server=${package_server}"

cd ${package_src}
echo "[$(date +'%Y-%m-%d %H:%M:%S')]正在上传文件scp ${package_name} ${package_server}:${package_target}"
scp ${package_name} ${package_server}:${package_target}
exit $?
