#!/bin/bash

target_dir=$1
package_type=$2

cd ${target_dir}
pwd
case ${package_type} in 
biz|app|http|tcp|crm|website)
    ls | grep '.war' | xargs -I@ zip @.zip @
    echo $?
    ;;
umall)
    ;;
h5)
    zip $(dirname ${target_dir}).zip $(dirname ${target_dir})
    ;;
*)
    ;;
esac
exit 0
