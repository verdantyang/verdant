#!/bin/bash

project_name=$1
server_name=$2
package_version=$3

echo "[$(date +'%Y-%m-%d %H:%M:%S')]正在调用远程脚本进行应用发布"
ssh -t -o "StrictHostKeyChecking no" -o PasswordAuthentication=no ${server_name}  "/script/${project_name}.sh ${package_version}"
exit $?
