#!/bin/bash

git_work_dir=$1
git_branch=$2

#加载配置文件
if [ -f ./setenv.sh ]; then
    . ./setenv.sh
fi

#获取当前分支
query_current_branch(){
	git branch | grep '\*' | awk '{print $2}' | xargs -I@ echo "[$(date +'%Y-%m-%d %H:%M:%S')]当前分支为：@"
	echo "[$(date +'%Y-%m-%d %H:%M:%S')]切换分支 ${git_branch} 成功"
}

#更新本地仓库
update_branch(){
	grep -q 'did not match any file(s) known to git.' _checkout.log
    if [ $? -eq 0 ]; then
        cat _checkout.log
        echo "[$(date +'%Y-%m-%d %H:%M:%S')]正在更新本地分支"
        git fetch 2>&1
    fi
}

#切换分支
checkout_branch(){
	git checkout -f ${git_branch} 2>&1 >_checkout.log
	error_code=$?

	#分支切换失败时检查是否因为本地仓库分支没有更新，如果是则更新
	#如果分支切换成功则查询当前分支并且退出
	if [ ${error_code} -ne 0 ]; then
		update_branch
	else
		query_current_branch
		exit 0
	fi
}

#任务开始
cd ${git_work_dir}
error_code=0
checkout_branch
checkout_branch
if [ ${error_code} -ne 0 ]; then
	echo "[$(date +'%Y-%m-%d %H:%M:%S')]分支${git_branch}没有找到，切换分支失败！"
	exit 1
fi
