#!/bin/bash

mvn_work_dir=$1
mvn_conf=$2
package_type=$3

#加载配置文件
if [ -f ./setenv.sh ]; then
    . ./setenv.sh
fi

#调用Maven打包
cd ${mvn_work_dir}
case ${package_type} in 
biz-trip|caocao-oss|caocao-tcpapp|caocao-admins|caocao-website)
    mvn_options="clean package"
    ;;
umall|order)
    mvn_options="clean package -P prod install assembly:assembly -U";;
h5)
    exit 0 ;;
esac
mvn ${mvn_options} -Dmaven.test.skip=true -s ${mvn_conf} 2>&1
exit $?
