#/bin/bash

#获取执行参数
if [ $# -lt 1 ]; then
    echo "没有Git分支，调用无效"
    exit 5
fi

#项目设置
script_name=$0
git_origin=origin
git_branch=$1
project_name=order
server_name=

#操作日志变量
work_dir=/workspace/publish
mvn_conf=${work_dir}/settings.xml
log_dir=${work_dir}/logs/${project_name}/detail
mkdir -p ${log_dir} 2>&1 1>/dev/null
log_file=${log_dir}/$(date +'%Y%m%d%H%M%S').log
log_report_file=${work_dir}/logs/${project_name}/report.log
current_timestamp=$(date +'%Y%m%d%H%M%S')

#任务工作变量
base_dir=/workspace/projects
git_work_dir=${base_dir}/${project_name}
mvn_work_dir=${base_dir}/${project_name}
scp_file_dir=${mvn_work_dir}/target
package_target=${mvn_work_dir}/target
report_msg=

#计算耗时
calc_diff_time(){
    p1=$1
    p2=$(date +'%s')
    let tt=p2-p1
    echo $tt
}


#检查是否出错，如果出错则退出
checkerror(){
    t1=$1
    if [ ${errorcode} -ne 0 ]; then
        report_msg="${report_msg}:failed package:failed elapsetime:$(calc_diff_time ${appts1})s"
        echo "${report_msg}" >> ${log_report_file}
        exit ${errorcode}
    else
        report_msg="${report_msg}:success:$(calc_diff_time ${t1})s "
    fi
}

#调用脚本
call_script(){
    t1=$(date +'%s')
    script_type=$2
    script_name=$1
    script_parameter=$3
    report_msg="${report_msg}${script_type}"
    sh ${script_name} ${script_parameter} | 
        tee -a ${log_file}; errorcode=${PIPESTATUS[0]}
    checkerror ${t1}
}

#结束任务
end_task(){
    exit_code=$1
    task_status=$2
    report_msg="${report_msg} package:${task_status} elapsetime:$(calc_diff_time ${appts1})s"
    echo "${report_msg}" >> ${log_report_file}
    echo "[${current_timestamp}]结束发包-----" | tee -a ${log_file}
    exit ${exit_code}
}

#重复版本检测
check_repeat_version(){
    #检测包名是否规范
    package_version=$1
    echo "${package_version}" | grep -q "/"
    if [ $? -eq 0 ]; then
        package_name=$(echo "${package_version}" | sed 's/^.*\/\(.*.zip\).*$/\1/g')
        echo "[$(date +'%Y-%m-%d %H:%M:%S')]包名称不规范，规范包名为：${project_name}-version.zip，当前包名为：${package_name}" | tee -a ${log_file}
        end_task 7 failed
    fi

    #检测包是否在已发列表中
    grep "${package_version}" "${log_report_file}" | grep -q "package:success"
    if [ $? -eq 0 ] ; then
        report_msg="${report_msg}version:${package_version} "
        echo "[$(date +'%Y-%m-%d %H:%M:%S')]该版本${package_version}已经发布，请升级版本号，本次操作失败！" | tee -a ${log_file}
        end_task 6 failed
    fi
}

#任务开始
appts1=$(date +'%s')
report_msg="${current_timestamp} ${project_name} "
echo "[${current_timestamp}]正在发包-----" | tee -a ${log_file} 

#1. 切换本地分支到指定分支
call_script "./git_checkout.sh" "git-checkout" "${git_work_dir} ${git_branch}"
#2. 获取最新代码
call_script "./git_pull.sh" "git-pull" "${git_work_dir} ${git_origin} ${git_branch}"
#3. 调用Maven打包
call_script "./mvn_build.sh" "mvn" "${mvn_work_dir} ${mvn_conf} ${project_name}"
#4. 压缩包
#5. 上传包
package_version=$(ls ${package_target}/*.zip | head -1 | sed "s/^.*${project_name}-\(.*\).zip$/\1/")
check_repeat_version ${package_version}
call_script "./scp_package.sh" "version:${package_version} scp" \
    "${project_name}-${package_version}.zip ${package_target} /home/admin/dubbo/${project_name} app03"
call_script "./scp_package.sh" "version:${package_version} scp" \
    "${project_name}-${package_version}.zip ${package_target} /home/admin/dubbo/${project_name} app04"
#6. 调用远程脚本发包
call_script "./ssh_call.sh" "ssh" "${project_name} app03 ${package_version}"
call_script "./ssh_call.sh" "ssh" "${project_name} app04 ${package_version}"
#任务结束
end_task 0 success
