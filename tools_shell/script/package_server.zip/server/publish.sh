#!/bin/bash

git_origin=origin
git_branch=$1
publish_server=$2
git_work_dir=$3
mvn_work_dir=$4
work_dir=/workspace/publish
mvn_conf=${work_dir}/settings.xml
log_dir=${work_dir}/$(date +'%Y%m%d-%H%M%S')
log_file=${work_dir}/publish.log
log_report_file=${work_dir}/report.log


#Git更新代码
sh ./git_checkout.sh ${git_work_dir} ${git_branch} | tee -a ${log_file} ; errorcode=$PIPESTATUS[0]
if [ ${errorcode} -ne 0 ]; then
    exit ${errorcode}
fi















if [ $errorcode neq 0 ]; then
    echo "切换版本失败，原因" | tee -a ${log_file}
    exit
fi
