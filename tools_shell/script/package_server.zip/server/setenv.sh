#/bin/bash
alias git=/usr/local/git/bin/git
alias mvn=/usr/local/maven/bin/mvn
